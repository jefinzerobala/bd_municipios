package br.com.jeferson.ApiMunicipios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiMunicipiosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiMunicipiosApplication.class, args);
	}

}
